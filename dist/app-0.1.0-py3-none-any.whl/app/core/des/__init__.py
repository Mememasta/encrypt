__all__ = ['DesKey']

from .base import DesKey
