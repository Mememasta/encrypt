# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app',
 'app.api.api_v1',
 'app.api.api_v1.endpoints',
 'app.core',
 'app.core.des',
 'app.core.nondet',
 'app.core.wiegener']

package_data = \
{'': ['*'], 'app': ['static/*', 'template/*']}

install_requires = \
['Jinja2>=2.11.2,<3.0.0',
 'aiofiles>=0.6.0,<0.7.0',
 'fastapi>=0.62.0,<0.63.0',
 'uvicorn>=0.12.3,<0.13.0']

setup_kwargs = {
    'name': 'app',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
