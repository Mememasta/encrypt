from .des import DesKey
from .wiegener import Wiegener